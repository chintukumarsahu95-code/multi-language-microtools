# Micro Tools Project

This repository contains small micro-tools and basic programs written in multiple programming languages.  
Each folder includes simple example programs such as "Hello World", basic arithmetic operations, and foundational syntax for learning different languages.

The Languages Included
- C
- C++
- Python
- Java
- JavaScript
- HTML/CSS

## The Project Structure
Each programming language has its own dedicated folder, and inside each folder you will find the corresponding code files.