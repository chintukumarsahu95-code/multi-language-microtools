#include <iostream>
using namespace std;

int main() {
    cout << "Hello World from C++!" << endl;
    return 0;
}